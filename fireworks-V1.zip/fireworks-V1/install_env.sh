nohup ansible-playbook  -i ansible_hosts.py  env_work.yml > ansible_env.log 2>&1  &
tailf ansible_env.log
