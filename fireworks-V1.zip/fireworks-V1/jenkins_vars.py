#!/usr/bin/python
#-*-coding:utf-8 -*-

import yaml

def get_app(data):
    del data['belong_to']
    del data['svnSource']
    del data['svnVersion']
    del data['appBaseDir']
    del data['appLocation']
    return data
def get_facade(data):
    del data['svnSource']
    del data['svnVersion']
    return data
jenkins_job = {}
job_webs = []
job_services = []
job_facades = []
with open("app_sources/app.yaml") as f_app:
    job_apps = yaml.load(f_app)

with open("env.yaml") as f_env:
    job_envs = yaml.load(f_env)

for k  in job_apps:
    if k in ['app_webs']:
        for app in job_apps[k]:
            app_envs = []
            for app_env in job_envs['envs']:
                env = {}
                env['name'] = app_env['name']
                env['description'] = app_env['description']
                app_servers = []
                for server in job_envs[app_env['mark']]:
                    if app['belong_to'] == server['owner']:
                        app_server = {}
                        app_server['name'] = u"服务器"
                        app_server['ip'] = server['host_name']
                        app_server['appBaseDir'] = app['appBaseDir']
                        app_server['appLocation'] = app['appLocation']
                        app_servers.append(app_server)
                env['svnSource'] = app['svnSource']
                env['svnVersion'] = app['svnVersion']
                env['servers'] = app_servers
                app_envs.append(env)
            app_web = get_app(app)
            app_web['envs'] = app_envs
            job_webs.append(app_web)
        
    if k in ['app_services']:
        for app in job_apps[k]:
            app_envs = []
            for app_env in job_envs['envs']:
                env = {}
                env['name'] = app_env['name']
                env['description'] = app_env['description']
                app_servers = []
                for server in job_envs[app_env['mark']]:
                    if app['belong_to'] == server['owner']:
                        app_server = {}
                        app_server['name'] = u"服务器"
                        app_server['ip'] = server['host_name']
                        app_server['appBaseDir'] = app['appBaseDir']
                        app_server['appLocation'] = app['appLocation']
                        app_servers.append(app_server)
                env['svnSource'] = app['svnSource']
                env['svnVersion'] = app['svnVersion']
                env['servers'] = app_servers
                app_envs.append(env)
            app_service = get_app(app)
            app_service['envs'] = app_envs
            job_services.append(app_service)
     
    if k in ['app_facades']:
        for app in job_apps[k]:
            app_envs = []
            for app_env in job_envs['envs']:
                env = {}
                env['name'] = app_env['name']
                env['description'] = app_env['description']
                env['svnSource'] = app['svnSource']
                env['svnVersion'] = app['svnVersion']
                app_envs.append(env)
            app_facade = get_facade(app)
            app_facade['envs'] = app_envs
            job_facades.append(app_facade)

jenkins_job['jenkins_job_webs'] = job_webs
jenkins_job['jenkins_job_services'] = job_services
jenkins_job['jenkins_job_facades'] = job_facades

f = open("host_vars/"+job_envs['jenkins_master'],"w")
yaml.dump(jenkins_job,f,allow_unicode = True)
f.close()
