#!/usr/bin/python
#-*-coding:utf-8 -*-

import os
import sys
import yaml

env_name = ""
for i in range(1, len(sys.argv)):
    env_name = sys.argv[1]
hosts_dir_path = "host_vars/"
groups_dir_path = "group_vars/"
with open("env.yaml") as f_env:
    ansible_envs = yaml.load(f_env)
env_hosts = []
env_mark = ""
for ansible_env  in  ansible_envs['envs']:
    if env_name in  [ansible_env['name']]:
        env_mark = ansible_env['mark']
        env_hosts = ansible_envs[ansible_env['mark']]

groups_vars_filepath = groups_dir_path+env_mark
if  os.path.exists(groups_vars_filepath):
    print("------------->清除分组["+env_name+"]变量<-----------------------")
    os.remove(groups_vars_filepath)


for host_server in  env_hosts:
    filepath = hosts_dir_path+host_server['host_name']
    if  os.path.exists(filepath):
        print("------------->清除主机["+host_server['host_name']+"]变量<-----------------------")
        os.remove(filepath)

env_source_locks = {}
env_locks = []
if  os.path.exists(".env_source.lock"):
    with open(".env_source.lock") as f_env_lock:
        env_source_locks = yaml.load(f_env_lock)
        env_locks = env_source_locks['env_source_locks']
if env_name  in  env_locks:
        env_locks.remove(env_name)
env_source_locks['env_source_locks'] = env_locks
lock_env_file = open(".env_source.lock",'w')
yaml.dump(env_source_locks,lock_env_file,allow_unicode = True)
lock_env_file.close()
