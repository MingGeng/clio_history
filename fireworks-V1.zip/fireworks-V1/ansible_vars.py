#!/usr/bin/python
#-*-coding:utf-8 -*-

import yaml
import os
import sys

def mkdir(path):
    folder = os.path.exists(path)
    if not folder:               #判断是否存在文件夹如果不存在则创建为文件夹
        os.makedirs(path)        #makedirs 创建文件时如果路径不存在会创建这个路径
env_name = ""
for i in range(1, len(sys.argv)):
    env_name = sys.argv[1]
if not env_name:
    env_name = raw_input("请输入环境名称:")
env_source_locks = {}
env_locks = []
if  os.path.exists(".env_source.lock"):
    with open(".env_source.lock") as f_env_lock:
        env_source_locks = yaml.load(f_env_lock)
        env_locks = env_source_locks['env_source_locks']
if  env_name in  env_locks:
    print("有人正在使用该环境资源")
else:
    env_locks.append(env_name)
    env_source_locks['env_source_locks'] = env_locks
    lock_env_file = open(".env_source.lock",'w')
    yaml.dump(env_source_locks,lock_env_file,allow_unicode = True)
    lock_env_file.close()
    env_infos = {'env_name':env_name,'is_exist':False}
    hosts_dir_path = "host_vars"
    env_hosts_file = "env_vars_base/env_hosts/"
    groups_dir_path = "group_vars"
    env_groups_file = "env_vars_base/env_groups/"
    with open("env.yaml") as f_env:
        ansible_envs = yaml.load(f_env)
    env_hosts = []
    env_mark = ""
    for ansible_env  in  ansible_envs['envs']:
        if env_name in  [ansible_env['name']]:
            env_infos['is_exist'] = True
            env_mark = ansible_env['mark']
            env_hosts = ansible_envs[ansible_env['mark']]

    if not env_infos['is_exist']:
        print("您输入的环境名称有误,请验证后再执行!")
    else:
        #groups_dir_path = groups_dir_path
        #mkdir(groups_dir_path)
        print("------------------------->环境名称["+env_name+"]"+"<-------------->分组变量<-----------------------")
        with open(env_groups_file+"clio.yaml") as f_group:
            group_var =  yaml.load(f_group)
        for env_host in env_hosts:
            host_name = env_host['host_name']
            if env_host['owner']  in  ["middleware_common"]:
                group_var['zooKeeper_address'] = host_name+":2181"
                group_var['redis_ip'] = host_name
                group_var['activemq_ip'] = host_name
                group_var['mongodb']['master_ip'] = host_name
                group_var['mongodb']['slaver_ip'] = host_name
            if env_host['owner']  in  ["nginx_common"]:
                group_var['nginx_ip'] = host_name
            if env_host['owner']  in  ["amis_db"]:
                group_var['amis_dataSource']['ip'] = host_name
            if env_host['owner']  in  ["lifepro_db"]:
                group_var['lifepro_dataSource']['ip'] = host_name
            if env_host['owner']  in  ["imod_db"]:
                group_var['cmdm_dataSource']['ip'] = host_name
                group_var['product_dataSource']['ip'] = host_name
            if env_host['owner']  in  ["business_db"]:
                group_var['notify_dataSource']['ip'] = host_name
                group_var['file_dataSource']['ip'] = host_name
                group_var['img_dataSource']['ip'] = host_name
                group_var['health_dataSource']['ip'] = host_name
                group_var['mq_dataSource']['ip'] = host_name
                group_var['soa_dataSource']['ip'] = host_name
                group_var['newworkflow_dataSource']['ip'] = host_name
                group_var['workflow_dataSource']['ip'] = host_name
                group_var['um_dataSource']['ip'] = host_name        
            if env_host['owner']  in  ["hydra_db"]:
               group_var['hydra']['ip'] = host_name
        print("\t\t\t["+env_mark+"]")
        f = open(groups_dir_path+"/"+env_mark,'w')
        yaml.dump(group_var,f,allow_unicode = True)
        f.close()

        #hosts_dir_path = hosts_dir_path
        #mkdir(hosts_dir_path)
        print("------------------------->环境名称["+env_name+"]"+"<-------------->主机变量<-----------------------")
        for env_host in env_hosts:
            if env_host['owner']  in  ["pa_common","pa_sso","yy1_common","yy2_common","finance_common","hydra_common","yx_common","front_common","middleware_common"]:
                with open(env_hosts_file+env_host['owner']+".yaml") as f_host:
                    host_var = yaml.load(f_host)
                    f_data = open(hosts_dir_path+"/"+env_host['host_name'],'w')
                    yaml.dump(host_var,f_data,allow_unicode = True)
                    f_data.close()
                    print("\t\t\t["+env_host['host_name']+"]")
            if env_host['owner']  in ['nginx_common']:
                with open(env_hosts_file+"nginx_common.yaml") as f_host:
                    host_var = yaml.load(f_host)['nginx']
                    host_var['server_name'] = env_host['host_name']
                    backup_components =  host_var['backup_components']
                    for backup_component in backup_components:
                        for env_component_host in env_hosts:
                            if backup_component['belong_to'] == env_component_host['owner']:
                                backup_component['server_ip'] = env_component_host['host_name']
                        del backup_component['belong_to']
                    
                    host_var['backup_components'] = backup_components
                    hosts_nginx = {}
                    hosts_nginx['nginx'] = host_var
                    f_data = open(hosts_dir_path+"/"+env_host['host_name'],'w')
                    yaml.dump(hosts_nginx,f_data,allow_unicode = True)
                    f_data.close()
                    print("\t\t\t["+env_host['host_name']+"]")

        
