#!/usr/bin/python
#-*-coding:utf-8 -*-
'''
Example custom dynamic inventory script for Ansible, in Python.
使用说明:
在linux 上使用
- chmod  755  *.py
- vim的时候  先使用 :set ff=unix 在 :wq 保存 运行即可,可解决./inventory.py 出现了:No such file or directory的问题)
'''

import os
import sys
import yaml
import argparse

try:
    import json
except ImportError:
    import simplejson as json

class HostsInventory(object):

    def __init__(self):
        self.inventory = {}
        self.read_cli_args()

        # Called with `--list`.
        if self.args.list:
            self.inventory = self.hosts_inventory()
        # Called with `--host [hostname]`.
        elif self.args.host:
            # Not implemented, since we return _meta info `--list`.
            self.inventory = self.empty_inventory()
        # If no groups or vars are present, return empty inventory.
        else:
            self.inventory = self.empty_inventory()

        print json.dumps(self.inventory);

    # Example inventory for testing.
    def hosts_inventory(self):
        hosts_source = self.get_sources()
        return  hosts_source

    # Empty inventory for testing.
    def empty_inventory(self):
        return {'_meta': {'hostvars': {}}}

    # Empty inventory for testing.
    def get_sources(self):
        return  self.get_ops_date()

    # Read the command line args passed to the script.
    def read_cli_args(self):
        parser = argparse.ArgumentParser()
        parser.add_argument('--list', action = 'store_true')
        parser.add_argument('--host', action = 'store')
        self.args = parser.parse_args()
    # Read Jenkins paramters
    def get_ops_date(self):
        # 根据构建环境，产生主机信息
        with open("env.yaml") as f_env:
            ansible_envs = yaml.load(f_env)
        jenkins =  ansible_envs['jenkins_master']
        dataSources = {}
        hosts = []
        params = {'ansible_ssh_user':'imodule','ansible_ssh_pass':'imodule'}
        hostvars = {}
        hosts.append(jenkins)
        dataSources['jenkins_jobs'] = {'hosts':hosts,'vars':params}
        dataSources['_meta'] = {'hostvars':hostvars}
        return dataSources
# Get the inventory.
HostsInventory()
