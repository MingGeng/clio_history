---------------------任务编排--------------------------
1.部署集群环境的基础构件
(1) ansible_vars.py 指定集群环境名称
(2) ansible-playbook  -i ansible_hosts.py  env_work.yml

2. 将新集群环境配置到jenkins中
(1) jenkins_vars.py
(2) ansible-playbook  -i jenkins_hosts.py  jenkins_work.yml

